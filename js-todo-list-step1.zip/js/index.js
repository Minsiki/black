import TodoApp from "./component/TodoApp.js";

window.onload = () => {
  const todoApp = new TodoApp();
};